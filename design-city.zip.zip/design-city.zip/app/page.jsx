"use client";
import { useState } from "react";
import { motion, MotionConfig, AnimatePresence, useMotionValue, useMotionTemplate, useScroll, useSpring } from "framer-motion";

/* ====== РЕДАКТИРУЙТЕ ЗДЕСЬ: контакты и демо-контент ====== */
const CONTACT = {
  whatsapp: "77000000000",          // ДЕМО: номер без "+", например 77011234567
  instagram: "designcity.kz",       // ДЕМО: ник без "@"
};
const NAV = [["Услуги", "#services"], ["Портфолио", "#work"], ["О нас", "#about"], ["Контакты", "#contact"]];

const SERVICES = [
  ["Брендинг и айдентика", "Название, логотип, фирменный стиль и правила его применения — чтобы бренд узнавали на вывеске, упаковке и в соцсетях."],
  ["Наружная реклама", "Вывески, световые короба, билборды, оформление фасадов и транспорта: от макета до монтажа."],
  ["Полиграфия", "Визитки, каталоги, меню, упаковка. Подбор бумаги, печати и отделки под задачу."],
  ["Сайты и digital", "Лендинги и сайты на заказ, настройка рекламы, аналитика."],
  ["SMM и контент", "Стратегия, оформление профилей, фото- и видеосъёмка, ежемесячное ведение."],
];

const PROJECTS = [
  { name: "Aurum Dental", cat: "Брендинг", g: "radial-gradient(circle at 30% 20%, #4a3a16, #000 65%)", l: "A" },
  { name: "Steppe Coffee", cat: "Наружная реклама", g: "linear-gradient(150deg, #2b2412, #000 70%)", l: "S" },
  { name: "Sky Tower", cat: "Digital", g: "radial-gradient(circle at 80% 10%, #5a4519, #000 60%)", l: "T" },
  { name: "Kokshe Fest", cat: "Брендинг", g: "linear-gradient(210deg, #3b2f14, #000 65%)", l: "K" },
  { name: "Nomad Estate", cat: "Наружная реклама", g: "radial-gradient(circle at 20% 90%, #4a3a16, #000 60%)", l: "N" },
  { name: "Lumen Studio", cat: "Digital", g: "linear-gradient(120deg, #1d180c, #5a4519 120%)", l: "L" },
];
const FILTERS = ["Все", "Брендинг", "Наружная реклама", "Digital"];

const PERKS = [
  ["Один подрядчик на весь цикл", "Идея, дизайн, печать, монтаж и запуск — без передачи задач между студиями."],
  ["Дизайн под вашу аудиторию", "Начинаем с бизнеса и клиентов, а не с трендов. Никаких шаблонов с биржи."],
  ["Сроки и смета заранее", "Фиксируем этапы, правки и стоимость до начала работы."],
  ["Локальный рынок знаем изнутри", "Работаем в Кокшетау и области: понимаем улицы, сезон и вкусы города."],
];

const ease = [0.22, 1, 0.36, 1];
const Reveal = ({ children, delay = 0, className = "" }) => (
  <motion.div className={className} initial={{ opacity: 0, y: 28 }} whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, margin: "-80px" }} transition={{ duration: 0.9, delay, ease }}>{children}</motion.div>
);
const Rule = () => (
  <motion.div className="h-px origin-left bg-gradient-to-r from-gold via-gold/40 to-transparent"
    initial={{ scaleX: 0 }} whileInView={{ scaleX: 1 }} viewport={{ once: true }} transition={{ duration: 1.4, ease }} />
);
const wa = (text = "Здравствуйте! Хочу обсудить проект.") => `https://wa.me/${CONTACT.whatsapp}?text=${encodeURIComponent(text)}`;
const ig = `https://instagram.com/${CONTACT.instagram}`;

function Btn({ href, children, solid, ...p }) {
  return (
    <a href={href} {...p} className={`inline-flex items-center justify-center rounded-full px-7 py-3.5 text-sm font-semibold transition duration-300 active:scale-95 ${
      solid ? "bg-gold text-black hover:bg-gold-light" : "border border-gold/50 text-gold-light hover:border-gold hover:bg-gold/10"}`}>{children}</a>
  );
}

function Nav() {
  const [open, setOpen] = useState(false);
  return (
    <header className="fixed inset-x-0 top-0 z-40 border-b border-ink-line/60 bg-black/70 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 md:px-10">
        <a href="#top" className="font-display text-xl font-semibold tracking-[0.18em] text-gold-light">DESIGN CITY</a>
        <nav className="hidden gap-9 text-sm text-bone/80 md:flex">
          {NAV.map(([t, h]) => <a key={h} href={h} className="transition hover:text-gold">{t}</a>)}
        </nav>
        <Btn href={wa()} target="_blank" rel="noopener noreferrer" solid className="hidden md:inline-flex">Написать</Btn>
        <button aria-label="Меню" aria-expanded={open} onClick={() => setOpen(!open)} className="flex h-10 w-10 flex-col items-center justify-center gap-1.5 md:hidden">
          <span className={`h-px w-6 bg-gold transition ${open ? "translate-y-[3.5px] rotate-45" : ""}`} />
          <span className={`h-px w-6 bg-gold transition ${open ? "-translate-y-[3.5px] -rotate-45" : ""}`} />
        </button>
      </div>
      <AnimatePresence>
        {open && (
          <motion.nav initial={{ height: 0 }} animate={{ height: "auto" }} exit={{ height: 0 }} className="overflow-hidden md:hidden">
            <div className="flex flex-col gap-1 px-5 pb-6">
              {NAV.map(([t, h]) => <a key={h} href={h} onClick={() => setOpen(false)} className="border-b border-ink-line py-4 font-display text-3xl">{t}</a>)}
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}

function Hero() {
  const mx = useMotionValue(50), my = useMotionValue(40);
  const bg = useMotionTemplate`radial-gradient(520px circle at ${mx}% ${my}%, rgba(201,162,75,0.22), transparent 65%)`;
  const move = (e) => { const r = e.currentTarget.getBoundingClientRect(); mx.set(((e.clientX - r.left) / r.width) * 100); my.set(((e.clientY - r.top) / r.height) * 100); };
  const word = (w, d) => (
    <span className="block overflow-hidden pb-[0.08em]">
      {w.split("").map((c, i) => (
        <motion.span key={i} className="gold-text inline-block" initial={{ y: "110%" }} animate={{ y: 0 }}
          transition={{ duration: 1.1, delay: d + i * 0.06, ease }}>{c}</motion.span>
      ))}
    </span>
  );
  return (
    <section id="top" onMouseMove={move} className="relative flex min-h-[100svh] flex-col justify-end overflow-hidden px-5 pb-14 pt-32 md:px-10">
      <motion.div aria-hidden className="pointer-events-none absolute inset-0" style={{ background: bg }} />
      <div className="relative mx-auto w-full max-w-7xl">
        <h1 className="font-display text-[clamp(3.6rem,17vw,15rem)] font-medium leading-[0.86] tracking-tight">
          {word("DESIGN", 0.2)}{word("CITY", 0.65)}
        </h1>
        <motion.div className="mt-10 flex flex-col gap-8 md:flex-row md:items-end md:justify-between"
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1, delay: 1.5, ease }}>
          <p className="max-w-md font-display text-2xl italic leading-snug text-bone/80 md:text-3xl">
            Рекламное агентство в Кокшетау. Бренды, которые видно издалека.
          </p>
          <div className="flex flex-wrap gap-3">
            <Btn href="#work" solid>Смотреть работы</Btn>
            <Btn href={wa()} target="_blank" rel="noopener noreferrer">Обсудить проект</Btn>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function Heading({ children, sub }) {
  return (
    <Reveal className="mb-14 max-w-3xl">
      <h2 className="font-display text-5xl leading-[0.95] md:text-7xl">{children}</h2>
      {sub && <p className="mt-5 max-w-xl text-bone/60">{sub}</p>}
    </Reveal>
  );
}
const Section = ({ id, children }) => (
  <section id={id} className="mx-auto max-w-7xl scroll-mt-16 px-5 py-24 md:px-10 md:py-36">{children}</section>
);

function Services() {
  const [o, setO] = useState(0);
  return (
    <Section id="services">
      <Heading sub="Выберите направление, чтобы увидеть, что входит в работу. Список можно менять под агентство.">Что мы делаем</Heading>
      <div className="border-t border-ink-line">
        {SERVICES.map(([t, d], i) => (
          <div key={t} className="border-b border-ink-line">
            <button onClick={() => setO(o === i ? -1 : i)} aria-expanded={o === i}
              className="group flex w-full items-center justify-between gap-6 py-7 text-left md:py-9">
              <span className={`font-display text-3xl transition duration-500 md:text-5xl ${o === i ? "gold-text" : "text-bone group-hover:text-gold-light"}`}>{t}</span>
              <span className={`text-3xl font-light text-gold transition duration-500 ${o === i ? "rotate-45" : ""}`}>+</span>
            </button>
            <AnimatePresence initial={false}>
              {o === i && (
                <motion.p initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.5, ease }} className="max-w-2xl overflow-hidden pb-8 text-bone/65">{d}</motion.p>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </Section>
  );
}

function Work() {
  const [f, setF] = useState("Все");
  const list = PROJECTS.filter((p) => f === "Все" || p.cat === f);
  return (
    <Section id="work">
      <Heading sub="Демонстрационные проекты: названия и визуалы вымышлены. Замените их реальными кейсами агентства.">Портфолио</Heading>
      <div className="mb-10 flex flex-wrap gap-2">
        {FILTERS.map((x) => (
          <button key={x} onClick={() => setF(x)} aria-pressed={f === x}
            className={`rounded-full border px-5 py-2 text-sm transition ${f === x ? "border-gold bg-gold text-black" : "border-ink-line text-bone/70 hover:border-gold/60"}`}>{x}</button>
        ))}
      </div>
      <motion.div layout className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        <AnimatePresence mode="popLayout">
          {list.map((p) => (
            <motion.article layout key={p.name} initial={{ opacity: 0, scale: 0.94 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.94 }}
              transition={{ duration: 0.5, ease }} whileHover={{ y: -8 }}
              className="group relative aspect-[4/5] cursor-pointer overflow-hidden rounded-sm border border-ink-line transition-colors hover:border-gold/70"
              style={{ background: p.g }}>
              <span className="absolute -right-4 -top-10 select-none font-display text-[16rem] leading-none text-gold/15 transition duration-700 group-hover:scale-110 group-hover:text-gold/30">{p.l}</span>
              <span className="absolute left-4 top-4 rounded-full border border-gold/40 bg-black/50 px-3 py-1 text-xs text-gold-light">Демо</span>
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black via-black/70 to-transparent p-6 pt-24">
                <p className="text-sm text-gold">{p.cat}</p>
                <h3 className="font-display text-3xl">{p.name}</h3>
              </div>
            </motion.article>
          ))}
        </AnimatePresence>
      </motion.div>
    </Section>
  );
}

function About() {
  return (
    <Section id="about">
      <div className="grid gap-12 md:grid-cols-[1.1fr_1fr] md:gap-20">
        <Heading>Агентство полного цикла из Кокшетау</Heading>
        <Reveal delay={0.15} className="space-y-6 self-end text-lg leading-relaxed text-bone/70">
          <p>DESIGN CITY придумывает и производит рекламу: от названия и логотипа до вывески на фасаде и сайта, который приводит клиентов.</p>
          <p>Мы верим, что для местного бизнеса хороший дизайн — это не украшение, а инструмент продаж. Каждая работа начинается с разговора о ваших клиентах.</p>
          <p className="border-l border-gold pl-5 text-sm text-bone/45">Текст-заглушка. Добавьте историю агентства, год основания и команду, когда они будут готовы.</p>
        </Reveal>
      </div>
    </Section>
  );
}

function Perks() {
  return (
    <Section>
      <Heading>Почему с нами удобно работать</Heading>
      <div className="grid gap-px overflow-hidden rounded-sm bg-ink-line md:grid-cols-2">
        {PERKS.map(([t, d]) => (
          <motion.div key={t} whileHover={{ backgroundColor: "#14110A" }} className="bg-black p-8 md:p-12">
            <h3 className="font-display text-3xl text-gold-light md:text-4xl">{t}</h3>
            <p className="mt-4 max-w-sm text-bone/60">{d}</p>
          </motion.div>
        ))}
      </div>
    </Section>
  );
}

function Contact() {
  const [name, setName] = useState(""); const [task, setTask] = useState("");
  const send = (e) => {
    e.preventDefault();
    window.open(wa(`Здравствуйте! Меня зовут ${name}. ${task}`), "_blank", "noopener,noreferrer");
  };
  const field = "w-full border-b border-ink-line bg-transparent py-4 text-lg outline-none transition placeholder:text-bone/30 focus:border-gold";
  return (
    <Section id="contact">
      <div className="grid gap-14 md:grid-cols-2">
        <div>
          <Reveal><h2 className="gold-text font-display text-6xl leading-[0.95] md:text-8xl">Расскажите о задаче</h2></Reveal>
          <Reveal delay={0.1} className="mt-10 flex flex-wrap gap-3">
            <Btn href={wa()} target="_blank" rel="noopener noreferrer" solid>Написать в WhatsApp</Btn>
            <Btn href={ig} target="_blank" rel="noopener noreferrer">Instagram @{CONTACT.instagram}</Btn>
          </Reveal>
          <p className="mt-6 text-sm text-bone/40">Кокшетау, Казахстан. Контакты в коде демонстрационные.</p>
        </div>
        <Reveal delay={0.2}>
          <form onSubmit={send} className="space-y-6">
            <input required value={name} onChange={(e) => setName(e.target.value)} placeholder="Ваше имя" className={field} />
            <textarea required rows={3} value={task} onChange={(e) => setTask(e.target.value)} placeholder="Что нужно сделать?" className={field} />
            <button type="submit" className="rounded-full bg-gold px-8 py-4 text-sm font-semibold text-black transition hover:bg-gold-light active:scale-95">Отправить в WhatsApp</button>
          </form>
        </Reveal>
      </div>
    </Section>
  );
}

export default function Page() {
  const { scrollYProgress } = useScroll();
  const sx = useSpring(scrollYProgress, { stiffness: 120, damping: 25 });
  return (
    <MotionConfig reducedMotion="user">
      <motion.div style={{ scaleX: sx }} className="fixed inset-x-0 top-0 z-50 h-0.5 origin-left bg-gold" />
      <Nav />
      <main>
        <Hero />
        <Rule /><Services />
        <Rule /><Work />
        <Rule /><About />
        <Rule /><Perks />
        <Rule /><Contact />
      </main>
      <footer className="border-t border-ink-line px-5 py-8 text-sm text-bone/40 md:px-10">
        <div className="mx-auto flex max-w-7xl flex-wrap justify-between gap-3">
          <span>© {new Date().getFullYear()} DESIGN CITY, Кокшетау</span>
          <span>Проекты и тексты на сайте демонстрационные</span>
        </div>
      </footer>
    </MotionConfig>
  );
}
