import "./globals.css";
import { Cormorant_Garamond, Manrope } from "next/font/google";

const display = Cormorant_Garamond({ subsets: ["latin", "cyrillic"], weight: ["400", "500", "600"], style: ["normal", "italic"], variable: "--font-display" });
const sans = Manrope({ subsets: ["latin", "cyrillic"], variable: "--font-sans" });

export const metadata = {
  title: "DESIGN CITY — рекламное агентство, Кокшетау",
  description: "Брендинг, наружная реклама, полиграфия и digital в Кокшетау.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="ru" className={`${display.variable} ${sans.variable}`}>
      <body className="font-sans">{children}</body>
    </html>
  );
}
