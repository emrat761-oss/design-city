module.exports = {
  content: ["./app/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        gold: { DEFAULT: "#C9A24B", light: "#EBD6A1", deep: "#8A6A24" },
        ink: { DEFAULT: "#000000", soft: "#0D0C0A", line: "#2A2418" },
        bone: "#EFE8DA",
      },
      fontFamily: {
        display: ["var(--font-display)", "serif"],
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};
