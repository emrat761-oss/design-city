# DESIGN CITY
npm install && npm run dev  (http://localhost:3000)
Контакты и демо-контент: константы вверху app/page.jsx (CONTACT, SERVICES, PROJECTS, PERKS).
Деплой: Vercel (импорт репозитория).
